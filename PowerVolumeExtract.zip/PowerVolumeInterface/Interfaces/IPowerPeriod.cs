﻿
namespace PowerVolumeInterface
{
    public interface IPowerPeriod
    {
        int Period { get; set; }
        double Volume { get; set; }
    }
}
